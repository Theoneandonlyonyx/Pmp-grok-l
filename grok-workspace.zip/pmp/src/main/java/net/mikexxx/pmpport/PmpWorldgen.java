package net.mikexxx.pmpport;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.level.LevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/** registries of the world generation (feature + loot modifier) and the delayed growth of generated trees */
@Mod.EventBusSubscriber(modid = PmpMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class PmpWorldgen {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, PmpMod.MODID);
    public static final RegistryObject<Feature<PmpPatchConfig>> PATCH = FEATURES.register("patch", PmpPatchFeature::new);

    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> LOOT =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, PmpMod.MODID);
    public static final RegistryObject<Codec<? extends IGlobalLootModifier>> ADD_ITEMS = LOOT.register("add_items", PmpLootModifier.CODEC);

    /** Per dimension, insertion order. The value is the age in ticks. Duplicate positions are ignored. */
    private static final Map<ResourceKey<Level>, LinkedHashMap<BlockPos, Integer>> PENDING = new java.util.HashMap<>();
    private static final int MAX_PENDING = 600;
    private static final int MAX_AGE = 6000;
    private static final int MAX_GROW_PER_TICK = 3;

    private PmpWorldgen() {}

    public static void queueTree(ResourceKey<Level> dim, BlockPos pos) {
        BlockPos key = pos.immutable();
        synchronized (PmpWorldgen.class) {
            LinkedHashMap<BlockPos, Integer> map = PENDING.computeIfAbsent(dim, k -> new LinkedHashMap<>());
            if (map.containsKey(key)) return;
            if (map.size() >= MAX_PENDING) {
                Iterator<BlockPos> it = map.keySet().iterator();
                if (it.hasNext()) {
                    it.next();
                    it.remove();
                }
            }
            map.put(key, 0);
        }
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.level instanceof ServerLevel level)) return;
        BlockPos[] grow = null;
        int n = 0;
        synchronized (PmpWorldgen.class) {
            LinkedHashMap<BlockPos, Integer> map = PENDING.get(level.dimension());
            if (map == null || map.isEmpty()) {
                logProfile(level);
                return;
            }
            grow = new BlockPos[MAX_GROW_PER_TICK];
            Iterator<Map.Entry<BlockPos, Integer>> it = map.entrySet().iterator();
            while (it.hasNext() && n < MAX_GROW_PER_TICK) {
                Map.Entry<BlockPos, Integer> entry = it.next();
                BlockPos pos = entry.getKey();
                int age = entry.getValue() + 1;
                entry.setValue(age);
                // wait until the chunks around are loaded, give up after about 5 minutes
                if (!chunksReady(level, pos)) {
                    if (age > MAX_AGE) it.remove();
                    continue;
                }
                it.remove();
                grow[n++] = pos;
            }
            if (map.isEmpty()) PENDING.remove(level.dimension());
        }
        for (int i = 0; i < n; i++) {
            BlockPos pos = grow[i];
            BlockState s = level.getBlockState(pos);
            if (s.getBlock() instanceof SaplingTreeBlock sap) sap.growNow(level, pos, level.getRandom());
        }
        logProfile(level);
    }

    @SubscribeEvent
    public static void onUnload(LevelEvent.Unload e) {
        if (!(e.getLevel() instanceof ServerLevel level)) return;
        synchronized (PmpWorldgen.class) {
            PENDING.remove(level.dimension());
        }
    }

    private static boolean chunksReady(ServerLevel level, BlockPos pos) {
        return level.hasChunkAt(pos)
                && level.hasChunkAt(pos.offset(6, 0, 6))
                && level.hasChunkAt(pos.offset(-6, 0, -6))
                && level.hasChunkAt(pos.offset(6, 0, -6))
                && level.hasChunkAt(pos.offset(-6, 0, 6));
    }

    private static void logProfile(ServerLevel level) {
        if (!PmpStructures.PROFILE || level.dimension() != Level.OVERWORLD) return;
        if ((level.getGameTime() % 200L) != 0L) return;
        com.mojang.logging.LogUtils.getLogger().info("[pmp] structure profile {}", PmpStructures.profileLine());
    }
}
