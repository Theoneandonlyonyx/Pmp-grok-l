package net.mikexxx.pmpport;

import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.List;
import java.util.function.Supplier;

/** adds one random item of a list (seeds, rare flowers) to the listed chest loot tables, with a chance */
public class PmpLootModifier extends LootModifier {
    public static final Supplier<Codec<PmpLootModifier>> CODEC = Suppliers.memoize(() -> RecordCodecBuilder.create(inst -> codecStart(inst).and(inst.group(
            ResourceLocation.CODEC.listOf().fieldOf("tables").forGetter(m -> m.tables),
            ResourceLocation.CODEC.listOf().fieldOf("items").forGetter(m -> m.items),
            Codec.FLOAT.fieldOf("chance").forGetter(m -> m.chance),
            Codec.INT.fieldOf("min").forGetter(m -> m.min),
            Codec.INT.fieldOf("max").forGetter(m -> m.max),
            Codec.INT.fieldOf("kinds_min").forGetter(m -> m.kindsMin),
            Codec.INT.fieldOf("kinds_max").forGetter(m -> m.kindsMax)
    )).apply(inst, PmpLootModifier::new)));

    private final List<ResourceLocation> tables;
    private final List<ResourceLocation> items;
    private final float chance;
    private final int min;
    private final int max;
    private final int kindsMin;
    private final int kindsMax;

    public PmpLootModifier(LootItemCondition[] conditions, List<ResourceLocation> tables, List<ResourceLocation> items, float chance, int min, int max, int kindsMin, int kindsMax) {
        super(conditions);
        this.tables = tables;
        this.items = items;
        this.chance = chance;
        this.min = min;
        this.max = Math.max(min, max);
        this.kindsMin = Math.max(1, kindsMin);
        this.kindsMax = Math.max(this.kindsMin, kindsMax);
    }

    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext ctx) {
        if (items.isEmpty() || !tables.contains(ctx.getQueriedLootTableId())) return loot;
        RandomSource r = ctx.getRandom();
        if (r.nextFloat() >= chance) return loot;
        // 1-2 / 2-3 ... different items, each in its own amount
        java.util.List<ResourceLocation> pool = new java.util.ArrayList<>(items);
        int kinds = Math.min(pool.size(), kindsMin + r.nextInt(kindsMax - kindsMin + 1));
        for (int k = 0; k < kinds; k++) {
            Item it = ForgeRegistries.ITEMS.getValue(pool.remove(r.nextInt(pool.size())));
            if (it != null && it != Items.AIR) loot.add(new ItemStack(it, min + r.nextInt(max - min + 1)));
        }
        return loot;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC.get();
    }
}
