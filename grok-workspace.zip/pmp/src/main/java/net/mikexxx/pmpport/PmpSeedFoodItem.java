package net.mikexxx.pmpport;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

import javax.annotation.Nullable;
import java.util.List;

/**
 * One item that is both food and a seed (e.g. Taro Root): right-click a block to plant it,
 * right-click in the air (or where it cannot be placed) to eat it. Uses its own item name, not the block's.
 */
public class PmpSeedFoodItem extends ItemNameBlockItem {
    final int color;
    final String latin;

    public PmpSeedFoodItem(Block b, Properties p, int color, String latin) {
        super(b, p);
        this.color = color;
        this.latin = latin;
    }

    @Override
    public Component getName(ItemStack stack) {
        return PmpItem.colored(Component.translatable(this.getDescriptionId()), color);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tip, TooltipFlag flag) {
        PmpItem.tooltip(tip, latin, 0);
    }
}
