package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/**
 * Climbing vine plant (sweet peas, grape vine, kiwi, hop, ...). It is attached to the side of a solid block
 * (FACING = the side of the wall it clings to), can be climbed, and grows UP the wall: the top block ripens
 * through 4 stages (random ticks / bone meal) and when fully grown it adds a new block above itself,
 * up to MAX_HEIGHT blocks. Honeycomb stops the growth, an axe removes the wax.
 */
public class ClimbingPlantBlock extends Block implements BonemealableBlock {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    public static final IntegerProperty STAGE = IntegerProperty.create("stage", 0, 3);
    public static final BooleanProperty WAXED = BooleanProperty.create("waxed");
    public static final int MAX_HEIGHT = 6;

    private static final VoxelShape NORTH = Block.box(0.0D, 0.0D, 0.0D, 16.0D, 16.0D, 3.0D);
    private static final VoxelShape SOUTH = Block.box(0.0D, 0.0D, 13.0D, 16.0D, 16.0D, 16.0D);
    private static final VoxelShape WEST = Block.box(0.0D, 0.0D, 0.0D, 3.0D, 16.0D, 16.0D);
    private static final VoxelShape EAST = Block.box(13.0D, 0.0D, 0.0D, 16.0D, 16.0D, 16.0D);

    /** fruit item picked by right-click once a block is fully grown (kiwi, grapes, hops ...), null = none */
    private String harvest;

    public ClimbingPlantBlock withHarvest(String item) {
        this.harvest = item;
        return this;
    }

    public ClimbingPlantBlock(Properties props) {
        super(props);
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(FACING, Direction.NORTH).setValue(STAGE, 0).setValue(WAXED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING, STAGE, WAXED);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return switch (state.getValue(FACING)) {
            case SOUTH -> SOUTH;
            case WEST -> WEST;
            case EAST -> EAST;
            default -> NORTH;
        };
    }

    // ---------------------------------------------------------------- attaching

    private static boolean wallHolds(LevelReader level, BlockPos pos, Direction wallSide) {
        BlockPos wall = pos.relative(wallSide);
        return level.getBlockState(wall).isFaceSturdy(level, wall, wallSide.getOpposite());
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        return wallHolds(level, pos, state.getValue(FACING));
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        Direction clicked = ctx.getClickedFace();
        if (clicked.getAxis().isHorizontal()) {
            BlockState s = this.defaultBlockState().setValue(FACING, clicked.getOpposite());
            if (s.canSurvive(ctx.getLevel(), ctx.getClickedPos())) return s;
        }
        for (Direction d : ctx.getNearestLookingDirections()) {
            if (!d.getAxis().isHorizontal()) continue;
            BlockState s = this.defaultBlockState().setValue(FACING, d);
            if (s.canSurvive(ctx.getLevel(), ctx.getClickedPos())) return s;
        }
        return null;
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level,
                                  BlockPos pos, BlockPos neighborPos) {
        return state.canSurvive(level, pos) ? state : Blocks.AIR.defaultBlockState();
    }

    // ---------------------------------------------------------------- growth (upwards along the wall)

    /** Walks to the highest block of this column. One read per step, no intermediate positions. */
    private BlockPos.MutableBlockPos topOf(LevelReader level, BlockPos pos) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(pos.getX(), pos.getY(), pos.getZ());
        BlockPos.MutableBlockPos above = new BlockPos.MutableBlockPos(pos.getX(), pos.getY() + 1, pos.getZ());
        while (level.getBlockState(above).is(this)) {
            p.set(above);
            above.move(Direction.UP);
        }
        return p;
    }

    private int heightFromTop(LevelReader level, BlockPos top) {
        int h = 1;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(top.getX(), top.getY() - 1, top.getZ());
        while (level.getBlockState(p).is(this)) {
            h++;
            p.move(Direction.DOWN);
        }
        return h;
    }

    private boolean canExtend(LevelReader level, BlockPos top, BlockState st, int height) {
        if (height >= MAX_HEIGHT) return false;
        BlockPos up = top.above();
        if (!level.getBlockState(up).isAir()) return false;
        return wallHolds(level, up, st.getValue(FACING));
    }

    private boolean canGrow(LevelReader level, BlockPos pos) {
        BlockPos.MutableBlockPos top = topOf(level, pos);
        BlockState st = level.getBlockState(top);
        if (!st.is(this)) return false;
        return st.getValue(STAGE) < 3 || canExtend(level, top, st, heightFromTop(level, top));
    }

    private void growStep(Level level, BlockPos pos) {
        BlockPos.MutableBlockPos top = topOf(level, pos);
        BlockState st = level.getBlockState(top);
        if (!st.is(this) || st.getValue(WAXED)) return;
        if (st.getValue(STAGE) < 3) {
            level.setBlock(top, st.setValue(STAGE, st.getValue(STAGE) + 1), 2);
            return;
        }
        int height = heightFromTop(level, top);
        if (!canExtend(level, top, st, height)) return;
        level.setBlock(top.above(), this.defaultBlockState().setValue(FACING, st.getValue(FACING))
                .setValue(STAGE, 0).setValue(WAXED, false), 3);
    }

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(WAXED)) return;
        if (level.getBlockState(pos.above()).is(this)) {                    // only the top block grows ...
            // ... except fruiting plants: a picked lower block ripens again
            if (harvest != null && state.getValue(STAGE) < 3 && level.getRawBrightness(pos, 0) >= 9 && random.nextInt(6) == 0)
                level.setBlock(pos, state.setValue(STAGE, state.getValue(STAGE) + 1), 2);
            return;
        }
        if (level.getRawBrightness(pos, 0) >= 9 && random.nextInt(4) == 0) growStep(level, pos);
    }

    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state, boolean isClient) {
        return !state.getValue(WAXED) && canGrow(level, pos);
    }

    @Override
    public boolean isBonemealSuccess(Level level, RandomSource random, BlockPos pos, BlockState state) {
        return true;
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource random, BlockPos pos, BlockState state) {
        growStep(level, pos);
    }

    // ---------------------------------------------------------------- waxing / axing

    private void setWax(Level level, BlockPos pos, boolean wax) {
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos(pos.getX(), pos.getY(), pos.getZ());
        BlockPos.MutableBlockPos below = new BlockPos.MutableBlockPos(pos.getX(), pos.getY() - 1, pos.getZ());
        while (level.getBlockState(below).is(this)) {
            p.set(below);
            below.move(Direction.DOWN);
        }
        while (true) {
            BlockState st = level.getBlockState(p);
            if (!st.is(this)) break;
            level.setBlock(p, st.setValue(WAXED, wax), 2);
            p.move(Direction.UP);
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        boolean waxed = state.getValue(WAXED);
        if (held.is(Items.HONEYCOMB) && !waxed) {
            if (!level.isClientSide) {
                setWax(level, pos, true);
                level.levelEvent(null, 3003, pos, 0);
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (held.getItem() instanceof AxeItem && waxed) {
            if (!level.isClientSide) {
                setWax(level, pos, false);
                level.levelEvent(null, 3004, pos, 0);
                held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (harvest != null && state.getValue(STAGE) >= 3) {
            if (!level.isClientSide) {
                Item it = ForgeRegistries.ITEMS.getValue(new ResourceLocation(PmpMod.MODID, harvest));
                if (it != null) Block.popResource(level, pos, new ItemStack(it, 1 + level.random.nextInt(2)));
                level.setBlock(pos, state.setValue(STAGE, 1), 2);
                level.playSound(null, pos, SoundEvents.SWEET_BERRY_BUSH_PICK_BERRIES, SoundSource.BLOCKS, 1.0F, 0.8F + level.random.nextFloat() * 0.4F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
