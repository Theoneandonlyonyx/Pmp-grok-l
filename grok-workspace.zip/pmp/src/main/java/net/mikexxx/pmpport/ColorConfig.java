package net.mikexxx.pmpport;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Colour filters of the "All Plants" tab.
 * The built-in sorting lives inside the jar (pmp_mikexxx_colortab.json). The config file config/pmp_mikexxx_colortab.toml
 * only contains the names of the colour lists, empty. Whatever the player writes into a list is moved there (and removed
 * from the list it was in), at the top of that list, in the order it was typed. Everything else stays as built in.
 */
public final class ColorConfig {
    public static final String[] KEYS = {"burgundy", "red", "orange", "yellow", "cream", "green", "blue", "cyan", "purple", "pink", "white", "other"};
    private static final Map<String, List<ResourceLocation>> CATS = new LinkedHashMap<>();
    private static final List<ResourceLocation> ALL = new ArrayList<>();
    private static boolean loaded = false;

    private ColorConfig() {}

    private static JsonObject readDefaults() {
        try (InputStream in = ColorConfig.class.getResourceAsStream("/pmp_mikexxx_colortab.json")) {
            if (in == null) return new JsonObject();
            return JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (Exception e) {
            return new JsonObject();
        }
    }

    /** "flower_red" -> "pmp_mikexxx:flower_red"; ids with a namespace (minecraft:dandelion, othermod:rose) are used as they are */
    static String idOf(String entry) {
        String id = entry;
        int hash = id.indexOf('#');
        if (hash >= 0) id = id.substring(0, hash);
        id = id.trim();
        if (id.isEmpty()) return id;
        return id.indexOf(':') >= 0 ? id : PmpMod.MODID + ":" + id;
    }

    private static List<String> defaultList(JsonObject o, String key) {
        List<String> out = new ArrayList<>();
        if (o.has(key) && o.get(key).isJsonArray()) {
            for (JsonElement e : o.getAsJsonArray(key)) {
                String id = idOf(e.getAsString());
                if (!id.isEmpty() && ResourceLocation.tryParse(id) != null) out.add(id);
            }
        }
        return out;
    }

    private static final String TEMPLATE_HEAD = "# Pmp mikexxx newport - colour filters of the 'All Plants' creative tab\n"
            + "#\n"
            + "# The normal sorting is built into the mod. This file is only for changes.\n"
            + "# To move something into another colour: write its id between the brackets of that colour, e.g.\n"
            + "#     red = [\"flower_tulip_orange\", \"minecraft:dandelion\"]\n"
            + "# - ids of this mod need no namespace, any other item or block of the game or of other mods needs it (minecraft:dandelion).\n"
            + "# - what you list is taken out of the colour it was in and shown at the top of the colour you list it in, in the order you write it.\n"
            + "# - an empty list changes nothing. Delete this file to start from scratch.\n\n";

    private static void writeTemplate(Path file) throws java.io.IOException {
        StringBuilder sb = new StringBuilder(TEMPLATE_HEAD);
        for (String k : KEYS) sb.append(k).append(" = []\n");
        Files.write(file, sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    /** reads "name = [ "a", "b" ]" lists (several lines allowed, # starts a comment) */
    private static Map<String, List<String>> readUser(Path file) throws java.io.IOException {
        Map<String, List<String>> out = new LinkedHashMap<>();
        StringBuilder text = new StringBuilder();
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            boolean inQuote = false;
            int cut = line.length();
            for (int i = 0; i < line.length(); i++) {
                char c = line.charAt(i);
                if (c == '"') inQuote = !inQuote;
                else if (c == '#' && !inQuote) { cut = i; break; }
            }
            text.append(line, 0, cut).append('\n');
        }
        Matcher m = Pattern.compile("([A-Za-z_]+)\\s*=\\s*\\[([^\\]]*)\\]").matcher(text);
        while (m.find()) {
            List<String> ids = new ArrayList<>();
            Matcher q = Pattern.compile("\"([^\"]*)\"").matcher(m.group(2));
            while (q.find()) ids.add(q.group(1));
            out.put(m.group(1).toLowerCase(java.util.Locale.ROOT), ids);
        }
        return out;
    }

    public static synchronized void load() {
        if (loaded) return;
        loaded = true;
        JsonObject defaults = readDefaults();
        Map<String, List<String>> user = new LinkedHashMap<>();
        try {
            Path dir = FMLPaths.CONFIGDIR.get();
            Path file = dir.resolve("pmp_mikexxx_colortab.toml");
            if (!Files.exists(file)) {
                Files.createDirectories(dir);
                writeTemplate(file);
            } else {
                user = readUser(file);
            }
        } catch (Exception ignored) {
            user = new LinkedHashMap<>();
        }
        // what the player listed
        Set<String> moved = new LinkedHashSet<>();
        Map<String, List<ResourceLocation>> top = new LinkedHashMap<>();
        for (String k : KEYS) {
            List<ResourceLocation> l = new ArrayList<>();
            for (String raw : user.getOrDefault(k, new ArrayList<>())) {
                String id = idOf(raw);
                if (id.isEmpty() || ResourceLocation.tryParse(id) == null) continue;
                if (moved.add(id)) l.add(new ResourceLocation(id));
            }
            top.put(k, l);
        }
        // built-in lists without the moved ones
        Set<String> seen = new LinkedHashSet<>(moved);
        for (String k : KEYS) {
            List<ResourceLocation> l = new ArrayList<>(top.get(k));
            for (String id : defaultList(defaults, k)) {
                if (seen.add(id)) l.add(new ResourceLocation(id));
            }
            CATS.put(k, l);
        }
        for (String k : KEYS) ALL.addAll(CATS.get(k));
    }

    public static List<ResourceLocation> all() {
        load();
        return ALL;
    }

    public static List<ResourceLocation> category(String key) {
        load();
        if ("all".equals(key)) return ALL;
        List<ResourceLocation> l = CATS.get(key);
        return l == null ? new ArrayList<>() : l;
    }
}
